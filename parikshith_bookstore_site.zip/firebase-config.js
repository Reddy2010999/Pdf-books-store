
export const firebaseConfig = {
  apiKey: "AIzaSyD5eabtRXkVrFZqVd4tudD9cwQ6cibuWyE",
  authDomain: "parikshith-reddy-books-store.firebaseapp.com",
  projectId: "parikshith-reddy-books-store",
  storageBucket: "parikshith-reddy-books-store.appspot.com",
  messagingSenderId: "102247596219",
  appId: "1:102247596219:web:a9ad13f87f4fe65b78e99e"
};
